# AYOSO - Ayo Sholat Berjamaah (APK)

## Cara membuat APK di GitHub
1. Buat repository baru di GitHub (boleh Public agar link unduh bisa dibagikan).
2. Upload SELURUH isi folder ini (termasuk folder `.github`, `www`, `scripts`).
3. Buka tab **Actions** → workflow **Build AYOSO APK** → **Run workflow** (otomatis jalan juga saat push ke `main`).
4. Setelah hijau (±5-8 menit), buka **Releases** → unduh `AYOSO.apk`. Link halaman Release inilah yang dibagikan ke siapa pun.

## Tanda tangan tetap (sangat disarankan, SEKALI saja)
Tanpa ini, tiap build memakai kunci baru sehingga tidak bisa di-update di atas versi lama.
```
keytool -genkeypair -v -keystore ayoso.jks -alias ayoso -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 ayoso.jks     # hasilnya dimasukkan ke secret KEYSTORE_BASE64
```
GitHub → Settings → Secrets and variables → Actions → tambahkan:
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
Simpan file `ayoso.jks` & passwordnya di tempat aman (jangan hilang, jangan di-upload ke repo).

## Mengubah isi aplikasi
Edit `www/index.html`, commit → APK baru otomatis dibuat.
