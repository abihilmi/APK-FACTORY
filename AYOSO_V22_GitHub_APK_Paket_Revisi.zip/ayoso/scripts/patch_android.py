"""Patch AndroidManifest + gradle hasil `npx cap add android` (rotasi, izin lokasi, keamanan, R8, penandatanganan)."""
import re, pathlib

root = pathlib.Path("android")
mf = root / "app/src/main/AndroidManifest.xml"
m = mf.read_text(encoding="utf-8")

# Keamanan: tanpa backup, tanpa cleartext
m = m.replace("android:allowBackup=\"true\"", "android:allowBackup=\"false\"")
if "usesCleartextTraffic" not in m:
    m = m.replace("<application", "<application android:usesCleartextTraffic=\"false\" android:fullBackupContent=\"false\"", 1)
# Rotasi portrait + landscape (ikuti sensor)
if "screenOrientation" not in m:
    m = m.replace("<activity", "<activity android:screenOrientation=\"fullSensor\"", 1)
# Izin lokasi (GPS) + internet; layar tetap menyala tidak dipaksa
for p in ["ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION", "INTERNET"]:
    tag = f'<uses-permission android:name="android.permission.{p}" />'
    if p not in m:
        m = m.replace("</manifest>", f"    {tag}\n</manifest>")
mf.write_text(m, encoding="utf-8")

# Gradle: R8 shrink, signing dari properti
g = root / "app/build.gradle"
t = g.read_text(encoding="utf-8")
if "signingConfigs" not in t:
    t = t.replace("buildTypes {", """signingConfigs {
        release {
            storeFile file(System.getenv("KEYSTORE_PATH") ?: "release.jks")
            storePassword System.getenv("KEYSTORE_PASSWORD")
            keyAlias System.getenv("KEY_ALIAS")
            keyPassword System.getenv("KEY_PASSWORD")
        }
    }
    buildTypes {""", 1)
t = re.sub(r"(release \{\s*)minifyEnabled false", r"\1signingConfig signingConfigs.release\n            minifyEnabled true\n            shrinkResources true", t, count=1)
g.write_text(t, encoding="utf-8")
print("patch OK")
